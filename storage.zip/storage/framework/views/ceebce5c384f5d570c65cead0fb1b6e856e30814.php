
<!-- Start Shop Newsletter  -->

<!-- End Shop Newsletter --><?php /**PATH C:\xampp\htdocs\e-shop\resources\views/frontend/layouts/newsletter.blade.php ENDPATH**/ ?>